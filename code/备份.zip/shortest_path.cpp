
struct Edge{
	ll val;//边长（地理距离）
	Node *to;
	set<Way>::iterator belong;//这条边是哪个way或area的
};


inline void add_edge(Node *from, Node *to, set<Way>::iterator belong, int type=2)//建单/双向边，默认双向
{
	ll val=distance(from,to)*R;
//												printf("%lld ",val);
	from->edge.push_back((Edge){val,to,belong}),from->cnt_edge++;
	if(type==2)
		to->edge.push_back((Edge){val,from,belong}),to->cnt_edge++;
	return;
}

inline void build_graph()//建立图
{
	Way wy;
	Node *ndi,*ndj;
	int cnt=0;
	for(auto x=way.begin(); x!=area.end(); x++,cnt++)//遍历每一条way和area
	{
		if(x==way.end())//way遍历完了就切换到area
			x=area.begin();
		wy=*x;
		for(int i=1;i<wy.cnt_node;i++)//在node之间建边
		{
			add_edge(wy[i-1],wy[i],x);
		}
	}
	
	puts("Success: Build graph.");
	
	return;
}