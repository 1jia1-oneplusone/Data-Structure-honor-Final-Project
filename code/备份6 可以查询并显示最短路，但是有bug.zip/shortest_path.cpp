
struct Edge{//有向边
	ll val;//边长（地理距离*100）
	Node *from,*to;//端点
	vector<Way>::iterator belong;//这条边是哪个way或area的
};

struct sp_{//shortest_path() 的优先队列用到的结构体，需要封装一大堆东西
	ll dis; //距离
	Node *last,*now;
	int from; //from=1/2 从path_endpoint[0]/从path_endpoint[1]访问
	
};
inline const bool operator <(const sp_ &x,const sp_ &y)//重载<运算符，以便存放在priority_queue中
{
	return x.dis < y.dis;
}

inline void add_edge(Node *from, Node *to, vector<Way>::iterator belong, int type=2)//建单/双向边，默认双向
{
	ll val=distance(from,to)*R;
//												printf("%lld ",val);
	from->edge.push_back((Edge){val,from,to,belong}),from->cnt_edge++;
	if(type==2)
		to->edge.push_back((Edge){val,to,from,belong}),to->cnt_edge++;
	return;
}

inline void build_graph()//建立图
{
	Way wy;
	Node *ndi,*ndj;
	int cnt=0;
	for(auto x=way.begin(); x!=area.end(); x++,cnt++)//遍历每一条way和area
	{
		if(x==way.end())//way遍历完了就切换到area
			x=area.begin();
		wy=*x;
		for(int i=1;i<wy.cnt_node;i++)//在node之间建边
		{
			add_edge(wy[i-1],wy[i],x);
		}
	}
	
	puts("√ 建立图");
	
	return;
}

#define debug_sh_pa 
inline int shortest_path()//查询2点间最短路,a*双向搜索
{
	static priority_queue<sp_>q;
	static Node *x,*y,*v;
	static sp_ sp;
	static map<Node*,int>vis;//记录点是否访问过，1表示从path_endpoint[0]访问，2表示从path_endpoint[1]访问
	static map<Node*,Node*>last;//记录每个点的上一个点
	static map<Node*,ll>dis[2];//记录每个点离出发点的最短距离
	static int ok=0,home,cnt=0;
	static ll distanc=0LL;//整段路程的长度，不命名为distance是因为已经有一个同名函数了
	
	if(path_endpoint[0]==EMPTY_node || path_endpoint[1]==EMPTY_node)//没有选中2个点
	{
		puts("× 请在查询路径前选择2个点。确保地图上有2个靶子图案（不要求显示在屏幕中）。");
		return 0;
	}
	
	//初始化
	for(int i=0;i<=1;i+=1)q.push((sp_){0LL,path_endpoint[i],path_endpoint[i],i+1});//把2个端点扔进优先队列
	vis.clear();last.clear();
	ok=cnt=0;distanc=0LL;
	
	while(q.size())
	{
		cnt++;
		sp=q.top();q.pop();
		x=sp.now;y=sp.last;home=sp.from;
			#ifdef debug_sh_pa
				printf("%dth, id=%lld, from %d\n",cnt,x->id,home-1);
			#endif
		if(vis[x]>0 || cnt>=1000000)//如果这个点被访问过了，或者已经执行太久了
		{
			if(vis[x]==home)//如果是从同一个起点出发，访问了2次，就跳过
				continue;
			else//否则x是从2个起点分别访问到，那么就已经找到最优解了
			{
				ok=1;
				break;
			}
		}
		vis[x]=home;//标记访问
		last[x]=y;
		
		for(int i=0,tmp;i<x->cnt_edge;i++)//遍历所有相邻点，注意不是访问
		{
			v=x->edge[i].to;
			if(v==y)continue;
			if((*(x->edge[i].belong)).isarea)continue;//不能走area的边
			
			tmp=vis[v];
			if(tmp==home || (dis[home>>1].find(v)==dis[home>>1].end()? 0 : dis[home>>1][v]<sp.dis+x->edge[i].val) )//如果该点访问过了，或者最短距离更短，就跳过
				continue;
			
			dis[home>>1][v]=sp.dis+x->edge[i].val;
			q.push((sp_){-(sp.dis+x->edge[i].val),x,v,home});
		}
	}
	
	if(!ok)//没找到
	{
		puts("两点间没有相连路径或者相距太远，请选择其它点进行查询。");
		return 0;
	}
	
	cnt_path=0;
	
	for(v=y;last[v]!=v;cnt_path++,v=last[v])//先存一段
	{
		path_point[cnt_path]=v;
	}
	path_point[cnt_path++]=v;
	for(int i=0;i<cnt_path/2;i++)
	{
		swap(path_point[i],path_point[cnt_path-i-1]);
	}
	
	for(v=x;last[v]!=v;cnt_path++,v=last[v])//再存另一段
	{
		path_point[cnt_path]=v;
	}
	path_point[cnt_path]=v;
	
		#ifdef debug_sh_pa
			for(int i=0;i<=cnt_path;i++)printf("%lld ",path_point[i]->id);
			puts("");
		#endif
	
	distanc=dis[0][x]+dis[1][x];
	printf("两点间最短路径长度为：%lfm\n",distanc/100.0);
	return 1;
}