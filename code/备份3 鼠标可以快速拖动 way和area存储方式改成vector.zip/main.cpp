#define hide 
#define debug 
//#define debug_ge_at 
//#define debug_tr_wa 

#include <iostream>
#include <cstdio>
#include <algorithm>
#include <cmath>
#include <ctime>
#include <cstdlib>
#include <cstring>
#include <set>
#include <vector>
#include <map>
#include <windows.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <graphics.h>
#include "..\\tinyxml\\tinystr.h"
#include "..\\tinyxml\\tinystr.cpp"
#include "..\\tinyxml\\tinyxml.h"
#include "..\\tinyxml\\tinyxml.cpp"
#include "..\\tinyxml\\tinyxmlerror.cpp"
#include "..\\tinyxml\\tinyxmlparser.cpp"
using namespace std;

#include "common.cpp"
#include "read_map.cpp"
#include "calculate.cpp"
#include "shortest_path.cpp"
#include "draw.cpp"
#include "UI.cpp"


#define ll long long
#define dbl double

#ifndef hide//一些在common.cpp中定义过的东西
	const string EMPTY_string="---";
	const int EMPTY_number=-114514;
	const int N=1000000;
	
	struct Node;
	struct Way;
	struct Triple;
	TiXmlElement *root;
	dbl minlat,minlon,maxlat,maxlon;
	set<Node>node;//存储所有Node
	set<Triple>node_ll2id;//(lon,lat) to id，根据经纬度找点的id
	set<Way>way;//存储所有的道路（不封闭的Way）
	set<Way>area;//存储所有的区域（封闭的Way）
	set<string>tag_choice;//对应的tagv是yes或no的tagk
#endif

int main()
{
	initialize();
	
//	MessageBox(NULL,"Initialization Finished.","I am title",NULL);
	
//	main_draw1(1);//输出地图
	
	build_graph();
	
	main_ui();
	
	return 0;
}

/*
choice tag:
area
bridge
building
bus
covered
ferry
foot
historic
internet_access:fee
oneway
takeaway
tunnel
wheelchair
*/