

inline void ui_line(int x1,int y1,int x2,int y2,int col=-1,int thickness=-1)//用ege画线
{
	if(thickness>=0)
		setlinewidth(thickness);
	if(col>=0)
		setcolor(EGEARGB(0xFF, col>>16, col>>8, col));
	ege_line(b2cxy(x1,y1), b2cxy(x2,y2));
	return;
}


/*inline void ui_polygon(ege_point *p,int size,int col=-1)//用ege画多边形
{
	if(col>=0)
		setcolor(EGEARGB(0xFF, col>>16, col>>8, col));
	if(!size)return;
	ege_fillpoly(size, p);
	return;
}*/

//#define debug_ge_is 
inline void get_island(Node *a,Node *b)//从给定2点开始寻找并绘制岛屿（封闭曲线），类似凸包算法
{
	Node *beg=a,*v,*choose;
	ege_point tmp[20000];
	int cnt=0;
	dbl max_angle,tmp2,last_angle;
	Way tmpp;
	
	for(cnt=0; b!=beg ; cnt++,a=b,b=choose)
	{
		tmp[cnt]=(ege_point){b2cxy(a->x,a->y)};//先把上个点加上去
		
			#ifdef debug_ge_is
				printf("\n#%lld %d# ",b->id,cnt);
				settextjustify(CENTER_TEXT, CENTER_TEXT);
				setfont(10, 0, "宋体");
				setcolor(BLACK);
//				xyprintf(b2cxy(b->x, b->y), "%lld", cnt);
			#endif
		
		max_angle=-1000;
		for(int i=0;i<b->cnt_edge;i++)//寻找从上一条边开始，逆时针方向第一条边
		{
			v=b->edge[i].to;
			tmpp=*(b->edge[i].belong);
			if(v==a && b->cnt_edge>1 || tmpp["route"]=="ferry")
				continue;//(1)一般不会再访问上一个点，除非这个点是死胡同，只能掉头了 (2)不要走航线
			
			tmp2=calc_angle(b,a,v);//计算夹角
			
				#ifdef debug_ge_is
//					printf("%lld,%lf ",v->id,tmp2/pi*180);
				#endif
			
			if(tmp2 > max_angle)
			{
				max_angle=tmp2;
				choose=v;
			}
		}
		
	}
	
	setfillcolor(EGEARGB(0xFF, 197,240,211));
	ege_fillpoly(cnt-1,tmp);
//	setcolor(EGEARGB(0xFF, 0,0,0));
//	setlinewidth(4);
//	ege_drawpoly(cnt-1,tmp);
	
	return;
}

//#define debug_is 
inline void island()
{
	ege_point tmp[20000];
	get_island(node[1763041878],node[1763041608]);//绘制鼓浪屿岛的陆地，这两个点是从岛屿边缘任选的连续2个点
	
		#ifdef debug_is 
			puts("ok");
		#endif
	//绘制厦门岛的陆地
	Way wy;
	wy.id=334467999;
	wy=*area.find(wy);
		#ifdef debug_is
			wy.print();
		#endif
	for(int i=0; i<wy.cnt_node; i++)
	{
		tmp[i]=(ege_point){b2cxy(wy[i]->x,wy[i]->y)};
			#ifdef debug_is
				printf("%d ",i);
			#endif
	}
	setfillcolor(EGEARGB(0xFF, 197,240,211));
	ege_fillpoly(wy.cnt_node-1,tmp);
		#ifdef debug_is 
			puts("ok");
		#endif
	return;
}

//#define debug_ui1 
inline void ui1()
{
	setbkcolor(EGERGB(152,209,252));	//设置背景色为浅蓝（海的颜色）
	cleardevice();
	
	Way wy;
	Node *a,*b;
	
	int col[]={0x1335F2,0x32833A,0xE20F83,0x2236D8,0xFFFFFF};
	int cnt=0,frog,thickness=0;
	
	setlinewidth(2);//设置线宽
	
	island();//绘制2片岛屿	
	
	ege_point tmp[200];
	
	for(auto x=way.begin(); x!=area.end() ; x++,cnt++)//遍历所有way和area
	{
		if(x==way.end())//way遍历完了就切换到area
		{
			x=area.begin();
			setlinewidth(1);
			setcolor(EGEARGB(0xFF, 18,44,242));
			setfillcolor(EGEARGB(0xFF, 233,240,245));
		}
		wy=*x;
		
/*		if(!wy.isarea)//设置颜色
			setcolor(EGEARGB(0xFF, col[cnt%4]>>16, col[cnt%4]>>8, col[cnt%4]));*/
			
		if(wy.isarea)//area绘制填充多边形
		{
/*			if(wy["name"]!="外剑礁") //填充陆地，但是这个方法不好用，因此弃用
			{
				setfillcolor(EGEARGB(0xFF, 27,214,108));
				floodfillsurface(b2cxy(wy.midx,wy.midy),EGEARGB(0xFF, 152,209,252));
			}*/
			
			if(wy["cly"]=="no")continue; //厦门岛陆地区域，已经单独画过了
			
			//--------以上为特殊area----------
			
			frog=0;
			for(int i=0;i<wy.cnt_node;i++)
			{
				a=wy[i];
				if(check(a->x,a->y))frog=1;
//										printf("%d,%d ",b2cxy(a->x,a->y));
				tmp[i]=(ege_point){b2cxy((a->x),(a->y))};
			}
			if(frog)
			{
				ege_fillpoly(wy.cnt_node,tmp);//先画一团多边形色块
				ege_drawpoly(wy.cnt_node,tmp);//再描边
			}
		}
		else//way一段一段画直线
		{
			if(wy["route"]=="ferry")//航线
				setlinewidth(1);
			else if(wy["boundary"]=="administrative")//行政区域划分，由于在地图数据中不完整，因此干脆直接不显示
				continue;
			else//默认值
				setlinewidth(2),setcolor(EGEARGB(0xFF,col[cnt%4]>>16, col[cnt%4]>>8, col[cnt%4]));
			
			//--------以上为特殊way----------
			
			for(int i=1;i<wy.cnt_node;i++)
			{
				a=wy[i];
				b=wy[i-1];
				if(!check(a->x,a->y)&&!check(b->x,b->y))
					continue;
				ui_line(a->x,a->y,b->x,b->y);
			}
			
		}
	}
	
	cnt=0;
	for(auto x=node.begin() ; x!=node.end() ; x++,cnt++)//遍历孤立点
	{
		a=(*x).second;
		if(!check(a->x,a->y))//超出地图边界，就不画了
			continue;
		
			#ifdef debug_ui1 //这里的调试用来输出地图上特定点的id，以此来在地图文件中找到每一个特殊note/way的真实身份
				//设置文字样式，输出文字
/*				if(a->id==1223212343)
				{
					settextjustify(CENTER_TEXT, CENTER_TEXT);
					setfont(10, 0, "宋体");
					setcolor(BLACK);
					xyprintf(b2cxy(a->x, a->y), "%lld", a->id);
				}
				
				if(a->id==8168609858)
				{
					putpixel(b2cxy(a->x,a->y),EGEARGB(0xFF, 0,0,0));
					circle(b2cxy(a->x,a->y),5);
				}*/
			#endif
		
		if(a->is_isolated())//孤立点一般有很多tag
		{
			//do something
		}
	}
	
	
	puts("Success: Generate UI.");
//	getch();

	
	return;
}

inline void fix_mdxy()//修正move_dx和move_dy，不至于超出地图范围
{
	move_dx=max(move_dx,0);
	move_dx=min(move_dx, width_map_col - width_map_col/move_time[move_tm] );
	move_dy=max(move_dy,0);
	move_dy=min(move_dy, height_map_col - height_map_col/move_time[move_tm] );
	return;
}

//#define debug_ro 
inline int roll(mouse_msg msg)//滚轮调整地图大小，返回1/0 是否有实际调整地图大小
{
	if(msg.wheel==0)
		return 0;
	
	int xc=msg.x,yc=msg.y;//滚轮时鼠标的位置
	
	//计算彩色地图框的参数，具体演算过程见草稿纸
	//原则：滚轮时鼠标所在点 在地图上的位置不变
	if(msg.wheel>0&&move_time[move_tm+1])//放大
	{
		move_tm++;
		move_dx+=(move_time[move_tm] - move_time[move_tm-1]) * xc / move_time[move_tm] / move_time[move_tm-1];
		move_dy+=(move_time[move_tm] - move_time[move_tm-1]) * yc / move_time[move_tm] / move_time[move_tm-1];
			#ifdef debug_ro
				printf("%d,%d x%d\n",move_dx,move_dy,move_time[move_tm]);
			#endif
		fix_mdxy();
		return 1;
	}
	if(msg.wheel<0&&move_time[move_tm-1])//缩小
	{
		move_tm--;
		move_dx-=(move_time[move_tm+1] - move_time[move_tm]) * xc / move_time[move_tm] / move_time[move_tm+1];
		move_dy-=(move_time[move_tm+1] - move_time[move_tm]) * yc / move_time[move_tm] / move_time[move_tm+1];
			#ifdef debug_ro
				printf("%d,%d x%d\n",move_dx,move_dy,move_time[move_tm]);
			#endif
		fix_mdxy();
		return 1;
	}
	
	return 0;
}

inline int drag(int x1,int y1,int x2,int y2)//左键拖动地图位置，返回1/0 是否有实际拖动地图位置
{
	int tmp1=move_dx,tmp2=move_dy;
	move_dx+=(x1-x2)/move_time[move_tm];//等比例移动
	move_dy+=(y1-y2)/move_time[move_tm];
	fix_mdxy();
	return tmp1!=move_dx&&tmp2!=move_dy;//如果和一开始的dxdy一样，就不要再渲染了
}

#define debug_co 
inline int control()//处理全部鼠标信息 返回0：啥也不干 返回1：退出程序
{
	Triple tmp;
	int redraw=0;//表示需要何种程度的渲染
	int notclick=0;
	int x1,y1,x2,y2,cnt;
	
	mouse_msg msg;
	
	while(mousemsg())
	{
		redraw=0;
		notclick=0;
		
		msg=getmouse();
		
		if(msg.is_left() && msg.is_down())//左键按下，拖动
		{
				#ifdef debug_co
					printf("left pressed!\n");
				#endif
			mousepos(&x2,&y2);x1=x2,y1=y2;
			cnt=0;//计时器
			
			msg=getmouse();
			while(!(msg.is_left()&&msg.is_up()))//鼠标没有抬起来，因此是拖动
			{
				mousepos(&x2,&y2);
				
				if(drag(x1,y1,x2,y2))//如果动了
				{
					x1=x2,y1=y2;
					ui1();
					cnt+=1000;
				}
				cnt++;
				Sleep(1);
				msg=getmouse();
			}
			
				#ifdef debug_co
					printf("while done!\n");
				#endif
			
			if(cnt>1000)//如果鼠标动了 或者 左键按下一秒后才抬起，那么就不要判定为单击
			{
				notclick=1;
					#ifdef debug_co
						printf("drag!\n");
					#endif
			}
		}
		
		if(msg.is_left() && msg.is_up() && !notclick)//左键抬起，单击
		{
			tmp.x = msg.x;//获取鼠标位置
			tmp.y = msg.y;
			#ifdef debug_co
				printf("click!\n");
			#endif
			if(node_xy2id.find(tmp)!=node_xy2id.end())
			{
				tmp=*node_xy2id.find(tmp);
				printf("#%lld %d %d\n",tmp.nd->id,tmp.x,tmp.y);
			}
			else
			{
				puts("not found");
			}
		}
				
		if(msg.is_right() && msg.is_down())//右键按下，中止
		{
			isbreak=1;
			return 1;
		}
				
		if(msg.is_wheel())//滚动缩放地图
		{
			if(roll(msg))
				ui1();
		}
				
		Sleep(1);
	}
	return 0;
}

inline void main_ui()
{
	initgraph(width_map_col, height_map_col, INIT_RENDERMANUAL);//创建窗口
	
	setrendermode(RENDER_MANUAL);//设置为手动渲染模式，以后绘制完成后，需要使用getche()等等待类函数才会显示新画的东西
	ege_enable_aa(true);//开启抗锯齿(默认为不开启)					
	
	ui1();
	
	
	bool opt;
	
	while(1)
	{
		opt=control();
		if(isbreak)break;
	}
	
	
	closegraph();
	
	return;
}