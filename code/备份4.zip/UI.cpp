inline void ui_line(int x1,int y1,int x2,int y2,int col,int thickness);//用ege画线
inline void ui_natural(Way wy);//画自然景观（tagk="natural"）
inline void get_island(Node *a,Node *b);//从给定2点开始寻找并绘制岛屿（封闭曲线），类似凸包算法
inline void island();
inline void ui1();//绘制界面
inline void fix_mdxy();//修正move_dx和move_dy，不至于超出地图范围
inline int roll(mouse_msg msg);//滚轮调整地图大小，返回1/0 是否有实际调整地图大小
inline int drag(int &x1,int &y1,int x2,int y2);//鼠标左键拖动地图位置，返回1/0 是否有实际拖动地图位置
inline int move(int x,int y);//方向键改变地图位置，以坐标形式输入。返回1/0 是否有实际改变地图位置
inline int control();//处理全部鼠标信息 返回0：啥也不干 返回1：退出程序
inline void main_ui();


inline void ui_line(int x1,int y1,int x2,int y2,int col=-1,int thickness=-1)//用ege画线
{
	if(thickness>=0)
		setlinewidth(thickness);
	if(col>=0)
		setcolor(EGEARGB(0xFF, col>>16, col>>8, col));
	ege_line(b2cxy(x1,y1), b2cxy(x2,y2));
	return;
}

//wood stone beach bare_rock coastline water
inline void ui_natural(Way wy)//画自然景观（tagk="natural"）
{
	static int frog=0;
	static Node *a;
	static ege_point tmp[20000];
	static string k;
	k=wy["natural"];
	if(k=="beach"||k=="sand") setfillcolor(EGEARGB(0xFF, 250,250,232));
	else if(k=="water") setfillcolor(EGEARGB(0xFF, 173,213,254));
	else if(k=="wood"||wy["landuse"]=="grass") setfillcolor(EGEARGB(0xFF, 32,193,123));
	else if(k=="bare_rock"||k=="stone"||k=="coastline") setfillcolor(EGEARGB(0xFF, 153,153,153));
	else setfillcolor(RED);
	
	for(int i=0;i<wy.cnt_node;i++)
	{
		a=wy[i];
		if(check(b2cxy(a->x,a->y),1))frog=1;
		tmp[i]=(ege_point){b2cxy((a->x),(a->y))};
	}
	if(frog)//一个地图区域只要有一个点在地图范围内，就要整个都画，否则填充会出问题。
	{
		ege_fillpoly(wy.cnt_node,tmp);//画一团多边形色块
	}
	
	setfillcolor(EGEARGB(0xFF, 233,240,245));
	return;
}

//#define debug_ge_is 
inline void get_island(Node *a,Node *b)//从给定2点开始寻找并绘制岛屿（封闭曲线），类似凸包算法
{
	Node *beg=a,*v,*choose;
	ege_point tmp[20000];
	int cnt=0;
	dbl max_angle,tmp2,last_angle;
	Way tmpp;
	
	for(cnt=0; b!=beg ; cnt++,a=b,b=choose)
	{
		tmp[cnt]=(ege_point){b2cxy(a->x,a->y)};//先把上个点加上去
		
			#ifdef debug_ge_is
				printf("\n#%lld %d# ",b->id,cnt);
				settextjustify(CENTER_TEXT, CENTER_TEXT);
				setfont(10, 0, "宋体");
				setcolor(BLACK);
//				xyprintf(b2cxy(b->x, b->y), "%lld", cnt);
			#endif
		
		max_angle=-1000;
		for(int i=0;i<b->cnt_edge;i++)//寻找从上一条边开始，逆时针方向第一条边
		{
			v=b->edge[i].to;
			tmpp=*(b->edge[i].belong);
			if(v==a && b->cnt_edge>1 || tmpp["route"]=="ferry")
				continue;//(1)一般不会再访问上一个点，除非这个点是死胡同，只能掉头了 (2)不要走航线
			
			tmp2=calc_angle(b,a,v);//计算夹角
			
				#ifdef debug_ge_is
//					printf("%lld,%lf ",v->id,tmp2/pi*180);
				#endif
			
			if(tmp2 > max_angle)
			{
				max_angle=tmp2;
				choose=v;
			}
		}
		
	}
	
	setfillcolor(EGEARGB(0xFF, 197,240,211));
	ege_fillpoly(cnt-1,tmp);
//	setcolor(EGEARGB(0xFF, 0,0,0));
//	setlinewidth(4);
//	ege_drawpoly(cnt-1,tmp);
	
	return;
}

//#define debug_is 
inline void island()
{
	ege_point tmp[20000];
	get_island(node[1763041878],node[1763041608]);//绘制鼓浪屿岛的陆地，这两个点是从岛屿边缘任选的连续2个点
	
		#ifdef debug_is 
			puts("ok");
		#endif
	//绘制厦门岛的陆地
	Way wy;
	wy.id=334467999;
	wy=*lower_bound(area.begin(),area.end(),wy);
		#ifdef debug_is
			wy.print();
		#endif
	for(int i=0; i<wy.cnt_node; i++)
	{
		tmp[i]=(ege_point){b2cxy(wy[i]->x,wy[i]->y)};
			#ifdef debug_is
				printf("%d ",i);
			#endif
	}
	setfillcolor(EGEARGB(0xFF, 197,240,211));
	ege_fillpoly(wy.cnt_node-1,tmp);
		#ifdef debug_is 
			puts("ok");
		#endif
	return;
}

//#define debug_ui1 
inline void ui1()//绘制界面
{
	setbkcolor(EGERGB(152,209,252));	//设置背景色为浅蓝（海的颜色）
	cleardevice();
	
	Way wy;
	Node *a,*b;
	
	int col[]={CYAN,BROWN,BLUE,MAGENTA,0xFFFFFF};
	int cnt=0,frog,thickness=0;
	
	setlinewidth(2);//设置线宽
	
	island();//绘制2片岛屿	
	
	ege_point tmp[200];
	
	char text[256];//显示的字符
	
			
	setlinewidth(1);
	setcolor(EGEARGB(0xFF, 18,44,242));
	setfillcolor(EGEARGB(0xFF, 233,240,245));
	
	for(auto x=area.begin(); x!=way.end() ; x++,cnt++)//遍历所有way和area
	{
		if(x==area.end())//area遍历完了就切换到way
		{
			x=way.begin();
			cnt=0;
		}
		wy=*x;
		
/*		if(!wy.isarea)//设置颜色
			setcolor(EGEARGB(0xFF, col[cnt%4]>>16, col[cnt%4]>>8, col[cnt%4]));*/
		
//		if(check(b2cxy(wy.x1,wy.x2),2)&&check(b2cxy(wy.y1,wy.y2),3))//如果整个都在地图范围外面，就不画了
//			continue;
			
		if(wy.isarea) //area 绘制填充多边形
		{			
			if(wy["cly"]=="no") //厦门岛陆地区域，已经单独画过了
				continue;
			else if(wy["natural"]!=EMPTY_string || wy["landuse"]=="grass") //自然景观
			{
				ui_natural(wy);
				continue;
			}
			else if(wy["landuse"]=="residential") //小区，画了反而会覆盖里面包含的建筑
				continue;
			
			//--------以上为特殊area----------
			
			frog=0;
			for(int i=0;i<wy.cnt_node;i++)
			{
				a=wy[i];
				if(check(b2cxy(a->x,a->y),1))frog=1;
				tmp[i]=(ege_point){b2cxy((a->x),(a->y))};
			}
			if(frog)//一个地图区域只要有一个点在地图范围内，就要整个都画，否则填充会出问题。
			{
				ege_fillpoly(wy.cnt_node,tmp);//画一团多边形色块
				
				if(wy["building"]!=EMPTY_string || wy["leisure"]!=EMPTY_string)//如果是建筑或休闲设施，就描边
					ege_drawpoly(wy.cnt_node,tmp);
			}
		}
		
		else //way 一段一段画直线
		{
			if(wy["route"]=="ferry")//航线
				setlinewidth(1);
			else if(wy["boundary"]=="administrative")//行政区域划分，由于在地图数据中不完整，因此干脆直接不显示
				continue;
			else//默认值
				setlinewidth(2),setcolor(EGEARGB(0xFF,col[cnt%4]>>16, col[cnt%4]>>8, col[cnt%4]));
			
			//--------以上为特殊way----------
			
			for(int i=1;i<wy.cnt_node;i++)
			{
				a=wy[i];
				b=wy[i-1];
				ui_line(a->x,a->y,b->x,b->y);
			}
		}
		
	}
	
	if(move_tm>=3)//放大到一定倍数，开始显示文字
	{
		cnt=0;
		for(auto x=way.begin(); x!=area.end() ; x++,cnt++)//遍历所有way和area，显示文字
		{
			if(x==way.end())//way遍历完了就切换到area
			{
				x=area.begin();
				setcolor(EGEARGB(0xFF, 18,44,242));
			}
			
			wy=*x;
			
			if(wy["name:en"]!=EMPTY_string)
			{
				settextjustify(CENTER_TEXT, CENTER_TEXT);
				setfont(10*move_time[move_tm]/move_tm, 0, "Calibri", 0, 0, 100, 0, 0, 0);
				setbkcolor_f(EGEARGB(0,0xff,0xff,0xff));//文字背景透明
				
				if(!wy.isarea)//与对应的way同色
					setcolor(EGEARGB(0xFF,col[cnt%4]>>16, col[cnt%4]>>8, col[cnt%4]));
				
				if(wy.isarea) outtextxy( b2cxy(wy.avgx, wy.avgy), wy["name:en"].c_str());//area就输出在中心
				else outtextxy( b2cxy(wy.midx, wy.midy), wy["name:en"].c_str());//way就输出在中点
			}
		}
	}
	
	cnt=0;
	for(auto x=node.begin() ; x!=node.end() ; x++,cnt++)//遍历孤立点
	{
		if(!check(a->x,a->y))//超出地图边界，就不画了
			continue;
		
			#ifdef debug_ui1 //这里的调试用来输出地图上特定点的id，以此来在地图文件中找到每一个特殊note/way的真实身份
				//设置文字样式，输出文字
/*				if(a->id==1223212343)
				{
					settextjustify(CENTER_TEXT, CENTER_TEXT);
					setfont(10, 0, "宋体");
					setcolor(BLACK);
					xyprintf(b2cxy(a->x, a->y), "%lld", a->id);
				}
				
				if(a->id==8168609858)
				{
					putpixel(b2cxy(a->x,a->y),EGEARGB(0xFF, 0,0,0));
					circle(b2cxy(a->x,a->y),5);
				}*/
			#endif
		
		if(a->is_isolated())//孤立点一般有很多tag
		{
			//do something
		}
	}
	
	
//	puts("Success: Generate UI.");
//	getch();

	
	return;
}

inline void fix_mdxy()//修正move_dx和move_dy，不至于超出地图范围
{
	move_dx=max(move_dx,0);
	move_dx=min(move_dx, width_map_col - width_map_col/move_time[move_tm] );
	move_dy=max(move_dy,0);
	move_dy=min(move_dy, height_map_col - height_map_col/move_time[move_tm] );
	return;
}

//#define debug_ro 
inline int roll(mouse_msg msg)//滚轮调整地图大小，返回1/0 是否有实际调整地图大小
{
	if(msg.wheel==0)
		return 0;
	
	int xc=msg.x,yc=msg.y;//滚轮时鼠标的位置
	
	//计算彩色地图框的参数，具体演算过程见草稿纸
	//原则：滚轮时鼠标所在点 在地图上的位置不变
	if(msg.wheel>0&&move_time[move_tm+1])//放大
	{
		move_tm++;
		move_dx+=(move_time[move_tm] - move_time[move_tm-1]) * xc / move_time[move_tm] / move_time[move_tm-1];
		move_dy+=(move_time[move_tm] - move_time[move_tm-1]) * yc / move_time[move_tm] / move_time[move_tm-1];
			#ifdef debug_ro
				printf("%d,%d x%d\n",move_dx,move_dy,move_time[move_tm]);
			#endif
		fix_mdxy();
		return 1;
	}
	if(msg.wheel<0&&move_time[move_tm-1])//缩小
	{
		move_tm--;
		move_dx-=(move_time[move_tm+1] - move_time[move_tm]) * xc / move_time[move_tm] / move_time[move_tm+1];
		move_dy-=(move_time[move_tm+1] - move_time[move_tm]) * yc / move_time[move_tm] / move_time[move_tm+1];
			#ifdef debug_ro
				printf("%d,%d x%d\n",move_dx,move_dy,move_time[move_tm]);
			#endif
		fix_mdxy();
		return 1;
	}
	
	return 0;
}

inline int drag(int &x1,int &y1,int x2,int y2)//鼠标左键拖动地图位置，返回1/0 是否有实际拖动地图位置
{
	int tmp1=move_dx,tmp2=move_dy;
	move_dx+=(x1-x2)/move_time[move_tm];//等比例移动
	move_dy+=(y1-y2)/move_time[move_tm];
	fix_mdxy();
	if(tmp1!=move_dx)x1=x2;
	if(tmp2!=move_dy)y1=y2;
	return tmp1!=move_dx||tmp2!=move_dy;//如果和一开始的dxdy一样，就不要再渲染了
}

inline int move(int x,int y)//方向键改变地图位置，以坐标形式输入。返回1/0 是否有实际改变地图位置
{
	move_dx+=x*2;//移动
	move_dy+=y*2;
	fix_mdxy();
	return move_dx-x!=move_dx||move_dy-y!=move_dy;//如果和一开始的dxdy一样，就不要再渲染了
}

inline int click(mouse_msg msg)//鼠标单击左键，选择该处的点
{
	static Tuple_Node tmp,tmpp;tmp.nd=tmpp.nd=NULL;
	static set<Tuple_Node>::iterator tmpn;
	
	tmp.x=c2bx(msg.y);//获取鼠标位置
	tmp.y=c2by(msg.x);
	
	
	for(int i=-7;i<=7;i++)//在周围一圈找node
		for(int j=-7;j<=7;j++)
		{
			if(abs(i)+abs(j)>8)continue;
			tmpp.x=tmp.x+i;
			tmpp.y=tmp.y+j;
			tmpn=node_xy2id.find(tmpp);
			
			if(tmpn!=node_xy2id.end())//找到了
			{
				i=100;
				break;
			}
		}
	if(tmpn!=node_xy2id.end())//找到了
	{
		tmp=*tmpn;
		tmp.nd->print();
	}
	else
	{
		//puts("Failed: Cannot found the node.");
	}
	return 0;
}

#define debug_co 
inline int control()//处理全部鼠标信息 返回0：啥也不干 返回1：退出程序
{
	static PIMAGE png=newimage();//存储图片文件
	static int redraw=0;//表示需要何种程度的渲染
	static int notclick=0,isdrag=0;
	static int x1,y1,x2,y2;
	static ll cnt;
	
	static key_msg key;
	static mouse_msg msg;
	
	while(mousemsg() || kbmsg())
	{
		redraw=0;
		notclick=0;
		
		if(mousemsg())
		{
			msg=getmouse();
			
			if(msg.is_move())
			{
					#ifdef debug_co
//						printf("move %d ",isdrag);
					#endif
				if(isdrag)//如果是左键按下(即拖动)状态
				{
					x2=msg.x,y2=msg.y;
					if(cnt%5==0 && drag(x1,y1,x2,y2))//如果动了就渲染。添加cnt的条件是为了手动降帧，防止短时间大量渲染导致更加卡顿
					{
						ui1();
						cnt+=1000;
					}
				}
			}
			
			if(msg.is_left() && msg.is_down())//左键按下，拖动
			{
					#ifdef debug_co
//						printf("left pressed!\n");
					#endif
				x1=x2=msg.x;//记下当前鼠标位置
				y1=y2=msg.y;
				cnt=0;//计时器
				isdrag=1;//标记为按下
			}
			
			if(msg.is_left() && msg.is_up())//左键抬起，单击
			{
				if(cnt<=1000)//如果鼠标按下左键后动了 或者 一秒后才抬起，那么就不要判定为单击
				{
					click(msg);
				}
					#ifdef debug_co
//					else
//						printf("not click!\n");
					#endif
				isdrag=0;//重置拖动状态
				cnt=0;
					#ifdef debug_co
//						printf("%d ",isdrag);
					#endif
			}
					
			if(msg.is_right() && msg.is_down())//右键按下，中止
			{
				isbreak=1;
				return 1;
			}
			
			if(msg.is_mid() && msg.is_down())//中键按下，截图
			{
				getimage(png,0,0,width_map_col,height_map_col);//获取屏幕图像
				if(savepng(png, "Screenshot.png"))//输出.png文件，失败返回1
					puts("BOOM: Cannot saved screenshot.");
				else
					puts("Success: Saved screenshot.");
			}
					
			if(msg.is_wheel())//滚动，缩放地图
			{
				if(roll(msg))
					ui1();
			}
		}
		else if(kbmsg())
		{
			key=getkey();
			
			if(key.key==0x1b)//esc，退出
			{
				isbreak=1;
				return 1;
			}
			
			if(0x25<=key.key && key.key<=0x28)//左上右下，移动地图
			{
				if(move(fx[(key.key-0x25)*2+1],fy[(key.key-0x25)*2+1]))
					ui1();
					#ifdef debug_co
//						puts("move!");
					#endif
			}
			
		}
		
		if(isdrag)cnt++;//拖动的计时器
			#ifdef debug_co
//				printf("%d ",isdrag);
			#endif
		
		Sleep(1);
	}
	return 0;
}

inline void main_ui()
{
	initgraph(width_map_col, height_map_col, INIT_RENDERMANUAL);//创建窗口
	
	setrendermode(RENDER_MANUAL);//设置为手动渲染模式，以后绘制完成后，需要使用getche()等等待类函数才会显示新画的东西
	ege_enable_aa(true);//开启抗锯齿(默认为不开启)					
	
	ui1();//先画出最初的地图
	
	puts("Success: Generate UI.");
	
	bool opt;
	
	while(is_run())
	{
		opt=control();
		if(isbreak)break;
	}
	
	
	closegraph();
	
	return;
}